package org.firstinspires.ftc.visualizer;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public final class HttpServer {

    public interface Handler {
        Response handle(Request request) throws Exception;
    }

    public static final class Request {
        public final String method;
        public final String path;
        public final Map<String, String> query;
        public final byte[] body;

        Request(String method, String path, Map<String, String> query, byte[] body) {
            this.method = method;
            this.path = path;
            this.query = query;
            this.body = body;
        }

        public String param(String name) {
            return query.get(name);
        }

        public String bodyText() {
            return new String(body, UTF8);
        }
    }

    public static final class Response {
        final int status;
        final String contentType;
        final byte[] body;

        private Response(int status, String contentType, byte[] body) {
            this.status = status;
            this.contentType = contentType;
            this.body = body;
        }

        public static Response of(int status, String contentType, String body) {
            return new Response(status, contentType, body.getBytes(UTF8));
        }

        public static Response bytes(String contentType, byte[] body) {
            return new Response(200, contentType, body);
        }

        public static Response json(String json) {
            return of(200, "application/json; charset=utf-8", json);
        }

        public static Response html(String html) {
            return of(200, "text/html; charset=utf-8", html);
        }

        public static Response error(int status, String message) {
            return of(status, "application/json; charset=utf-8",
                    "{\"error\":" + jsonQuote(message) + "}");
        }
    }

    public static final class HttpException extends RuntimeException {
        public final int status;

        public HttpException(int status, String message) {
            super(message);
            this.status = status;
        }
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MAX_HEADER_LINE = 8192;
    private static final int MAX_BODY = 1024 * 1024;

    private final int port;
    private final Handler handler;
    private volatile ServerSocket serverSocket;
    private ExecutorService pool;

    public HttpServer(int port, Handler handler) {
        this.port = port;
        this.handler = handler;
    }

    public synchronized void start() throws IOException {
        if (serverSocket != null) return;
        final ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(port));
        serverSocket = ss;
        pool = Executors.newFixedThreadPool(4, new java.util.concurrent.ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "http-worker-" + port);
                t.setDaemon(true);
                return t;
            }
        });
        Thread acceptor = new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop(ss);
            }
        }, "http-accept-" + port);
        acceptor.setDaemon(true);
        acceptor.start();
    }

    public synchronized void stop() {
        ServerSocket ss = serverSocket;
        serverSocket = null;
        if (ss != null) {
            try {
                ss.close();
            } catch (IOException ignored) {
            }
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
    }

    public boolean isRunning() {
        return serverSocket != null;
    }

    private void acceptLoop(ServerSocket ss) {
        while (!ss.isClosed()) {
            try {
                final Socket socket = ss.accept();
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        serve(socket);
                    }
                });
            } catch (IOException e) {
                if (ss.isClosed()) break;
            } catch (RejectedExecutionException e) {
                break;
            }
        }
    }

    private void serve(Socket socket) {
        try {
            socket.setSoTimeout(10000);
            InputStream in = new BufferedInputStream(socket.getInputStream());
            OutputStream out = socket.getOutputStream();
            Response response;
            try {
                Request request = readRequest(in);
                response = dispatch(request);
            } catch (BadRequest e) {
                response = Response.error(400, e.getMessage());
            }
            write(out, response);
        } catch (IOException ignored) {
            // Client ran away
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private Response dispatch(Request request) {
        try {
            return handler.handle(request);
        } catch (HttpException e) {
            return Response.error(e.status, e.getMessage());
        } catch (SecurityException e) {
            return Response.error(403, e.getMessage());
        } catch (java.io.FileNotFoundException e) {
            return Response.error(404, "Not found");
        } catch (IllegalArgumentException e) {
            return Response.error(400, e.getMessage());
        } catch (Exception e) {
            return Response.error(500, String.valueOf(e));
        }
    }

    private static final class BadRequest extends IOException {
        BadRequest(String message) {
            super(message);
        }
    }

    private static Request readRequest(InputStream raw) throws IOException {
        InputStream in = raw;
        String requestLine = readLine(in);
        if (requestLine == null || requestLine.isEmpty()) {
            throw new BadRequest("Empty request");
        }
        String[] parts = requestLine.split(" ");
        if (parts.length < 2) {
            throw new BadRequest("Malformed request line");
        }
        String method = parts[0].toUpperCase(Locale.ROOT);
        String target = parts[1];

        Map<String, String> headers = new HashMap<>();
        String line;
        while ((line = readLine(in)) != null && !line.isEmpty()) {
            int colon = line.indexOf(':');
            if (colon > 0) {
                headers.put(line.substring(0, colon).trim().toLowerCase(Locale.ROOT),
                        line.substring(colon + 1).trim());
            }
        }

        int length = 0;
        String contentLength = headers.get("content-length");
        if (contentLength != null) {
            try {
                length = Integer.parseInt(contentLength);
            } catch (NumberFormatException e) {
                throw new BadRequest("Invalid Content-Length");
            }
        }
        if (length < 0 || length > MAX_BODY) {
            throw new BadRequest("Body too large");
        }
        byte[] body = new byte[length];
        new DataInputStream(in).readFully(body);

        String path = target;
        String rawQuery = "";
        int q = target.indexOf('?');
        if (q >= 0) {
            path = target.substring(0, q);
            rawQuery = target.substring(q + 1);
        }
        return new Request(method, path, parseQuery(rawQuery), body);
    }

    private static Map<String, String> parseQuery(String rawQuery) throws IOException {
        Map<String, String> result = new HashMap<>();
        if (rawQuery.isEmpty()) return result;
        for (String pair : rawQuery.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String key = eq >= 0 ? pair.substring(0, eq) : pair;
            String value = eq >= 0 ? pair.substring(eq + 1) : "";
            result.put(URLDecoder.decode(key, "UTF-8"), URLDecoder.decode(value, "UTF-8"));
        }
        return result;
    }

    private static String readLine(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') {
                byte[] bytes = buf.toByteArray();
                int len = bytes.length;
                if (len > 0 && bytes[len - 1] == '\r') len--;
                return new String(bytes, 0, len, UTF8);
            }
            if (buf.size() >= MAX_HEADER_LINE) {
                throw new BadRequest("Header line too long");
            }
            buf.write(b);
        }
        if (buf.size() == 0) return null;
        return new String(buf.toByteArray(), UTF8);
    }


    private static void write(OutputStream out, Response response) throws IOException {
        String head = "HTTP/1.1 " + response.status + " " + reason(response.status) + "\r\n"
                + "Content-Type: " + response.contentType + "\r\n"
                + "Content-Length: " + response.body.length + "\r\n"
                + "Cache-Control: no-cache\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(UTF8));
        out.write(response.body);
        out.flush();
    }

    private static String reason(int status) {
        switch (status) {
            case 200: return "OK";
            case 400: return "Bad Request";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 409: return "Conflict";
            case 413: return "Payload Too Large";
            default: return "Internal Server Error";
        }
    }
    public static String jsonQuote(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 2).append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.append('"').toString();
    }
}
