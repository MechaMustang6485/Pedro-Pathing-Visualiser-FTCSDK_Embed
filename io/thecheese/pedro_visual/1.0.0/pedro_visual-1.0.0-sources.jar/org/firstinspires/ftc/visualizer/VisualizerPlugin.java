package org.firstinspires.ftc.visualizer;

import android.content.Context;
import android.util.Log;

import com.qualcomm.ftccommon.FtcEventLoop;

import org.firstinspires.ftc.ftccommon.external.OnCreateEventLoop;
import org.firstinspires.ftc.ftccommon.external.OnDestroy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
public final class VisualizerPlugin {

    public static final int PORT = 8082;
    private static final String TAG = "Visualizer";
    private static final String ASSET_ROOT = "visualizer";
    private static final Object LOCK = new Object();

    private static HttpServer server;
    private static Context appContext;

    private VisualizerPlugin() {
    }

    @OnCreateEventLoop
    public static void attach(final Context context, final FtcEventLoop eventLoop) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                start(context);
            }
        }, "visualizer-startup");
        t.start();
    }

    private static void start(Context context) {
        synchronized (LOCK) {
            if (server != null && server.isRunning()) return;
            try {
                appContext = context.getApplicationContext();
                server = new HttpServer(PORT, new HttpServer.Handler() {
                    @Override
                    public HttpServer.Response handle(HttpServer.Request request) throws Exception {
                        return route(request);
                    }
                });
                server.start();
                Log.i(TAG, "Visualizer listening on port " + PORT);
                for (String ip : lanAddresses()) {
                    Log.i(TAG, "Open http://" + ip + ":" + PORT + " in a browser on this Wi-Fi network");
                }
            } catch (Throwable t) {
                Log.e(TAG, "Failed to start visualizer on port " + PORT, t);
            }
        }
    }

    @OnDestroy
    public static void detach(Context context) {
        synchronized (LOCK) {
            if (server != null) {
                server.stop();
                server = null;
            }
        }
    }

    private static HttpServer.Response route(HttpServer.Request req) throws IOException {
        if (!req.method.equals("GET") && !req.method.equals("HEAD")) {
            throw new HttpServer.HttpException(404, "Not found");
        }
        String path = safePath(req.path);
        if (path == null) {
            throw new HttpServer.HttpException(404, "Not found");
        }
        return HttpServer.Response.bytes(contentType(path), readAsset(ASSET_ROOT + "/" + path));
    }
    static String safePath(String rawPath) {
        String p;
        try {
            p = URLDecoder.decode(rawPath, "UTF-8");
        } catch (Exception e) {
            return null;
        }
        if (p.isEmpty() || p.equals("/")) return "index.html";
        if (!p.startsWith("/")) return null;
        p = p.substring(1);
        if (p.contains("..") || p.contains("\\") || p.indexOf('\0') >= 0 || p.endsWith("/")) {
            return null;
        }
        for (String part : p.split("/")) {
            if (part.isEmpty() || part.startsWith(".")) return null;
        }
        return p;
    }

    static String contentType(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html; charset=utf-8";
        if (lower.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (lower.endsWith(".css")) return "text/css; charset=utf-8";
        if (lower.endsWith(".json")) return "application/json; charset=utf-8";
        if (lower.endsWith(".webmanifest")) return "application/manifest+json; charset=utf-8";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".ico")) return "image/x-icon";
        if (lower.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    private static byte[] readAsset(String name) throws IOException {
        InputStream in;
        try {
            in = appContext.getAssets().open(name);
        } catch (IOException e) {
            throw new HttpServer.HttpException(404, "Not found");
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    private static List<String> lanAddresses() {
        List<String> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return out;
            for (NetworkInterface ni : Collections.list(ifaces)) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        out.add(addr.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
